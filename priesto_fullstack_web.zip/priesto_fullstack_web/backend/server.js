const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const socketio = require('socket.io');
const dotenv = require('dotenv');
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = socketio(server, { cors: { origin: '*' } });

const { User, Priest, Booking } = require('./src/models');

app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/priests', require('./src/routes/priest'));
app.use('/api/bookings', require('./src/routes/booking'));
app.use('/api/admin', require('./src/routes/admin'));

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('join', ({ room }) => {
    socket.join(room);
  });
  socket.on('priest:location', (data) => {
    io.to('booking:' + data.bookingId).emit('priest:location', data);
  });
  socket.on('booking:response', (data) => {
    io.to('user:' + data.userId).emit('booking:update', data);
  });
  socket.on('disconnect', ()=>{});
});

const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/priesto_full')
  .then(()=> server.listen(PORT, ()=> console.log('Server running on', PORT)))
  .catch(err=>console.error(err));

module.exports = { io };
