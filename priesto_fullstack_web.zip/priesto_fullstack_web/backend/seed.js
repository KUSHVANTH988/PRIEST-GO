const mongoose = require('mongoose'); const dotenv = require('dotenv'); dotenv.config();
const { User, Priest } = require('./src/models');
async function seed(){ await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/priesto_full');
  await User.deleteMany({}); await Priest.deleteMany({});
  const admin = await User.create({ name: 'Admin', email: 'admin@priesto.app', phone: '9999999999', role: 'admin' });
  const user = await User.create({ name: 'Test User', phone: '9000000002', role: 'user', location: { coordinates: [78.4867,17.3850] } });
  const priestUser = await User.create({ name: 'Pandit Ramesh', phone: '9000000001', role: 'priest' });
  const priest = await Priest.create({
    userId: priestUser._id, about: 'Experienced priest for weddings and housewarmings', languages: ['Telugu','Hindi'], experienceYears: 8,
    rituals: [ { key: 'housewarming', price: 2500 }, { key: 'marriage', price: 15000 }, { key: 'pooja', price: 500 } ],
    location: { coordinates: [78.4867,17.3850] }
  });
  console.log('Seed done'); process.exit(0);
}
seed();
