const mongoose = require('mongoose');
const { Schema } = mongoose;

const userSchema = new Schema({
  name: String, email: String, phone: String,
  role: { type: String, enum: ['user','priest','admin'], default: 'user' },
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] },
  createdAt: { type: Date, default: Date.now }
});
userSchema.index({ location: '2dsphere' });

const priestSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  photoUrl: String, about: String,
  rituals: [{ key: String, price: Number }],
  languages: [String], experienceYears: Number,
  rating: { type: Number, default: 5 }, verified: { type: Boolean, default: false },
  kycDocuments: [String],
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] },
});
priestSchema.index({ location: '2dsphere' });

const bookingSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  priestId: { type: Schema.Types.ObjectId, ref: 'Priest' },
  ritual: String, location: { address: String, lat: Number, lng: Number },
  priceEstimate: Number, scheduledAt: Date,
  status: { type: String, enum: ['requested','accepted','enroute','completed','cancelled'], default: 'requested' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = {
  User: mongoose.model('User', userSchema),
  Priest: mongoose.model('Priest', priestSchema),
  Booking: mongoose.model('Booking', bookingSchema)
};
