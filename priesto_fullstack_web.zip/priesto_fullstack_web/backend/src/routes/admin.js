const express = require('express'); const router = express.Router();
const { Priest } = require('../models');

// Admin - list priests
router.get('/priests', async (req,res)=> {
  const p = await Priest.find().populate('userId','name phone');
  res.json(p);
});

// Admin verify
router.post('/priests/:id/verify', async (req,res)=> {
  const p = await Priest.findByIdAndUpdate(req.params.id, { verified: true }, { new: true });
  res.json(p);
});

module.exports = router;
