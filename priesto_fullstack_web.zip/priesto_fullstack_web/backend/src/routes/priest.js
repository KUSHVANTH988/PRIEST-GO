const express = require('express'); const router = express.Router(); const { Priest } = require('../models');

router.get('/', async (req,res)=> {
  const { lat, lng, q, language, minExp } = req.query;
  const filters = {};
  if(language) filters.languages = language;
  if(minExp) filters.experienceYears = { $gte: Number(minExp) };
  if(q) filters.$or = [{ about: new RegExp(q,'i') }, { 'rituals.key': new RegExp(q,'i') }];
  if(lat && lng) {
    filters.location = { $near: { $geometry: { type: "Point", coordinates: [ Number(lng), Number(lat) ] }, $maxDistance: 20000 } };
  }
  const priests = await Priest.find(filters).limit(50);
  res.json(priests);
});

router.get('/:id', async (req,res)=> {
  const p = await Priest.findById(req.params.id).populate('userId','name phone');
  if(!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

module.exports = router;
