const express = require('express'); const router = express.Router();
const jwt = require('jsonwebtoken'); const { User } = require('../models');
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

router.post('/signup', async (req, res) => {
  const { name, phone, email, role } = req.body;
  let user = await User.findOne({ phone });
  if(!user) user = await User.create({ name, phone, email, role: role || 'user' });
  const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user });
});

router.post('/login', async (req,res)=> {
  const { phone } = req.body; const user = await User.findOne({ phone });
  if(!user) return res.status(404).json({ error: 'User not found' });
  const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user });
});

module.exports = router;
