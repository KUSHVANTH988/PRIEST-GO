const express = require('express'); const router = express.Router();
const { Booking } = require('../models'); const { io } = require('../../server');

router.post('/', async (req,res)=> {
  const data = req.body;
  const booking = await Booking.create(data);
  io.emit('booking:new', booking);
  res.json(booking);
});

router.get('/:id', async (req,res)=> {
  const b = await Booking.findById(req.params.id);
  if(!b) return res.status(404).json({ error: 'Not found' });
  res.json(b);
});

router.patch('/:id/status', async (req,res)=> {
  const { status } = req.body;
  const b = await Booking.findByIdAndUpdate(req.params.id, { status }, { new: true });
  io.to('booking:' + b._id).emit('booking:update', b);
  res.json(b);
});

module.exports = router;
