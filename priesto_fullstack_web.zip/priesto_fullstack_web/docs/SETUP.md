# Setup Full-Stack Priesto (Local)

Prereqs:
- Node 16+, npm
- MongoDB

1) Start backend:
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev

2) Start frontend:
cd web_app
npm install
npm run dev

Frontend runs on http://localhost:3001 and talks to backend http://localhost:4000/api by default.

Notes:
- Replace API URL by setting NEXT_PUBLIC_API env var.
- For real-time, frontend can connect to backend Socket.IO at ws://localhost:4000
