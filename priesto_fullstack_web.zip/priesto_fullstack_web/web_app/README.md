# Priesto Web App (Next.js)

Run:
1. cd web_app
2. npm install
3. npm run dev
Open http://localhost:3001
