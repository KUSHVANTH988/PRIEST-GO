import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

export default function Map({ priests }) {
  const center = [17.3850,78.4867];
  return (
    <MapContainer center={center} zoom={13} style={{height:'100%', width:'100%'}}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {priests.map(p=> (
        <Marker key={p._id} position={[p.location.coordinates[1], p.location.coordinates[0]]}>
          <Popup>{p.about} — {p.languages && p.languages.join(', ')}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
