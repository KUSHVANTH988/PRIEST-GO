module.exports = { reactStrictMode: true, env: { NEXT_PUBLIC_API: process.env.NEXT_PUBLIC_API || 'http://localhost:4000/api' } }
