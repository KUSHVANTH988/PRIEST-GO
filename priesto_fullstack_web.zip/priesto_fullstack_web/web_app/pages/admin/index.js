import React, {useEffect, useState} from 'react';
import axios from 'axios';
export default function Admin(){ const [priests,setPriests]=useState([]);
  useEffect(()=> axios.get(process.env.NEXT_PUBLIC_API + '/admin/priests').then(r=> setPriests(r.data)).catch(e=>console.error(e)), []);
  return (<div><header><h1>Admin Panel</h1></header><div className='container'><h2>Priests</h2>{priests.map(p=> (<div key={p._id} className='priest-card'><h3>{p.userId?.name}</h3><p>{p.about}</p><p>Verified: {p.verified ? 'Yes' : 'No'}</p><button onClick={async ()=>{ await axios.post(process.env.NEXT_PUBLIC_API + '/admin/priests/' + p._id + '/verify'); alert('Verified'); window.location.reload(); }}>Verify</button></div>))}</div></div>); }
