import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
export default function PriestProfile(){
  const router = useRouter(); const { id } = router.query;
  const [priest, setPriest] = useState(null);
  useEffect(()=> { if(!id) return; axios.get(process.env.NEXT_PUBLIC_API + '/priests/' + id).then(r=> setPriest(r.data)).catch(e=> console.error(e)); }, [id]);
  if(!priest) return <div className="container">Loading...</div>;
  return (
    <>
      <header><h1>Priesto — Priest Profile</h1></header>
      <div className="container">
        <h2>{priest.userId?.name || 'Priest'}</h2>
        <p>{priest.about}</p>
        <p>Languages: {(priest.languages||[]).join(', ')}</p>
        <p>Experience: {priest.experienceYears} yrs</p>
        <h3>Rituals & Prices</h3>
        <ul>{(priest.rituals||[]).map(r=> <li key={r.key}>{r.key} — ₹{r.price}</li>)}</ul>
        <button onClick={async ()=> {
          const userId = prompt('Enter your userId (from signup)') || '';
          const payload = { userId, priestId: priest._id, ritual: priest.rituals[0]?.key || 'pooja', location: { address: 'My Home', lat:17.3850, lng:78.4867 }, priceEstimate: priest.rituals[0]?.price || 500, scheduledAt: new Date().toISOString() };
          const res = await axios.post(process.env.NEXT_PUBLIC_API + '/bookings', payload);
          alert('Booking created: ' + res.data._id);
        }}>Book Priest</button>
      </div>
    </>
  )
}
