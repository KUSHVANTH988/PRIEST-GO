import React, {useEffect, useState} from 'react';
import axios from 'axios';
import dynamic from 'next/dynamic';
const Map = dynamic(()=> import('../src/Map'), { ssr: false });

export default function Home(){
  const [priests, setPriests] = useState([]);
  useEffect(()=> {
    axios.get(process.env.NEXT_PUBLIC_API + '/priests?lat=17.3850&lng=78.4867')
      .then(r=> setPriests(r.data))
      .catch(e=> console.error(e));
  }, []);
  return (
    <>
      <header><h1>Priesto — Hire a Priest</h1></header>
      <div className="container">
        <h2>Nearby Priests</h2>
        <div style={{display:'flex',gap:20}}>
          <div style={{flex:1}}>
            {priests.map(p=> (
              <div key={p._id} className="priest-card">
                <h3>{p.about}</h3>
                <p>Languages: {(p.languages||[]).join(', ')}</p>
                <p>Experience: {p.experienceYears} yrs</p>
                <p><a href={'/priest/' + p._id}>View profile</a></p>
              </div>
            ))}
          </div>
          <div style={{width:420, height:400}}>
            <Map priests={priests} />
          </div>
        </div>
      </div>
    </>
  )
}
